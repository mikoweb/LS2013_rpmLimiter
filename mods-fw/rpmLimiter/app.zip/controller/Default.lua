-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- rpmLimiter Mod
-- Default Controller
------------------------------------------------------------*/

local name = 'rpmLimiter_Controller_Default';
local _ = newclass(name, Controller);
_G[name] = _;

function _:init()
	self.super:init();
end;

function _:load()
	-- Model
	self:setModel('LimiterSpecialization');

	-- Views
	self:setView();
	self:setView('EditMenu');
end;

function _:loadSpecialization()
	if (g_currentMission.controlledVehicle ~= nil and g_currentMission.controlledVehicle.rpmLimiterSpecializationLoaded == nil) then
		local spec = rpmLimiterSpec();
		table.insert(g_currentMission.controlledVehicle.specializations, spec);
		spec:load(g_currentMission.controlledVehicle, self.ControllerPrefix);	
	end;
end;