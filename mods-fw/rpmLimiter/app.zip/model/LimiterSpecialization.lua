-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- rpmLimiter Mod
-- Specialization rpm limiter
------------------------------------------------------------*/

-- Model
local name = 'rpmLimiter_Model_LimiterSpecialization';
local _ = newclass(name, Model);
_G[name] = _;

function _:init()
end;

function _:load()
end;



-- Specialization
rpmLimiterSpecHelper = {}
rpmLimiterSpecHelper.SpecInstances = {}

function rpmLimiterSpecHelper:getInstance(index)
	if self.SpecInstances[index] == nil then
		self.SpecInstances[index] = {};
	end;	
	return self.SpecInstances[index];
end;


rpmLimiterSpec = newclass('rpmLimiterSpec');

function rpmLimiterSpec:init()
end;

function rpmLimiterSpec:load(Vehicle, modName)
	if Vehicle ~= nil and tonumber(Vehicle) == nil then
		g_currentMission.controlledVehicle.rpmLimiterSpecializationLoaded = true
		local this = rpmLimiterSpecHelper:getInstance(Vehicle.rootNode);
		
		this.modName = modName;
		this.Vehicle = Vehicle;
			
		this.input = Mods:getRegistry(this.modName, 'input');
		
		this.rpmLimiterWindow 			= Mods:getRegistry(this.modName, 'rpmLimiterWindow');
		this.rpmLimiterCaptionLimit 	= Mods:getRegistry(this.modName, 'rpmLimiterCaptionLimit');
		this.rpmEditRpmInput 			= Mods:getRegistry(this.modName, 'rpmEditRpmInput');
		this.rpmEditWindow 				= Mods:getRegistry(this.modName, 'rpmEditWindow');
		this.rpmEditUpButton 			= Mods:getRegistry(this.modName, 'rpmEditUpButton');
		this.rpmEditDownButton 			= Mods:getRegistry(this.modName, 'rpmEditDownButton');
		this.rpmLimiterIconSpeed0 		= Mods:getRegistry(this.modName, 'rpmLimiterIconSpeed0');
		this.rpmLimiterIconSpeed1 		= Mods:getRegistry(this.modName, 'rpmLimiterIconSpeed1');
		this.rpmLimiterIconSpeed2 		= Mods:getRegistry(this.modName, 'rpmLimiterIconSpeed2');
		this.rpmLimiterIconSpeed3 		= Mods:getRegistry(this.modName, 'rpmLimiterIconSpeed3');
		this.rpmLimiterIconSpeedS 		= Mods:getRegistry(this.modName, 'rpmLimiterIconSpeedS');
			
		this.maxRpmLimit = {}
		for k,v in pairs(this.Vehicle.motor.maxRpm) do
			this.maxRpmLimit[k] = v;
		end;		
			
		this.rpmXMLFile = XML:new();
		this.rpmXMLFile:open(Utils.getFilename('/rpm.xml', __DIR_GAME_MOD__..this.modName));
		local xmlSpeed1 = this.rpmXMLFile:getValue("rpm."..this.Vehicle.typeName..".speed1", "integer");
		local xmlSpeed2 = this.rpmXMLFile:getValue("rpm."..this.Vehicle.typeName..".speed2", "integer");
		local xmlSpeed3 = this.rpmXMLFile:getValue("rpm."..this.Vehicle.typeName..".speed3", "integer");
		local xmlSpeed4 = this.rpmXMLFile:getValue("rpm."..this.Vehicle.typeName..".speed4", "integer");
		if xmlSpeed1 ~= nil and xmlSpeed1<this.Vehicle.motor.maxRpm[1] then this.Vehicle.motor.maxRpm[1] = xmlSpeed1 end;
		if xmlSpeed2 ~= nil and xmlSpeed2<this.Vehicle.motor.maxRpm[2] then this.Vehicle.motor.maxRpm[2] = xmlSpeed2 end;
		if xmlSpeed3 ~= nil and xmlSpeed3<this.Vehicle.motor.maxRpm[3] then this.Vehicle.motor.maxRpm[3] = xmlSpeed3 end;
		if xmlSpeed4 ~= nil and xmlSpeed4<this.Vehicle.motor.maxRpm[4] then this.Vehicle.motor.maxRpm[4] = xmlSpeed4 end;
			
		function this.rpmIncrease(object, button, callbackData)
			if this.Vehicle.motor.speedLevel ~= 0 then
				if this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel]+100 <= this.maxRpmLimit[this.Vehicle.motor.speedLevel] then
					this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel] = this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel]+100;
					this.rpmXMLFile:setValue("rpm."..this.Vehicle.typeName..".speed"..this.Vehicle.motor.speedLevel, this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel], "integer");
				else this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel] = this.maxRpmLimit[this.Vehicle.motor.speedLevel] end;
			else
				if this.Vehicle.motor.maxRpm[3]+100 <= this.maxRpmLimit[3] then
					this.Vehicle.motor.maxRpm[3] = this.Vehicle.motor.maxRpm[3]+100;
					this.rpmXMLFile:setValue("rpm."..this.Vehicle.typeName..".speed3", this.Vehicle.motor.maxRpm[3], "integer");
				else this.Vehicle.motor.maxRpm[3] = this.maxRpmLimit[3] end;
			end;
			this.rpmXMLFile:save();
		end;
					
		function this.rpmDecrease(object, button, callbackData)
			if this.Vehicle.motor.speedLevel ~= 0 then
				if this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel]-100 >= 0 then
					this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel] = this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel]-100;
					this.rpmXMLFile:setValue("rpm."..this.Vehicle.typeName..".speed"..this.Vehicle.motor.speedLevel, this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel], "integer");
				else this.Vehicle.motor.maxRpm[this.Vehicle.motor.speedLevel] = 0 end;
			else
				if this.Vehicle.motor.maxRpm[3]-100 >= 0 then
					this.Vehicle.motor.maxRpm[3] = this.Vehicle.motor.maxRpm[3]-100;
					this.rpmXMLFile:setValue("rpm."..this.Vehicle.typeName..".speed3", this.Vehicle.motor.maxRpm[3], "integer");
				else this.Vehicle.motor.maxRpm[3] = 0 end;
			end;
			this.rpmXMLFile:save();
		end;	

		function this.changeSpeedIcon(speedLevel) 
			if speedLevel == 0 then this.rpmLimiterIconSpeed0.visible = true
			else this.rpmLimiterIconSpeed0.visible = false end;
			if speedLevel == 1 then this.rpmLimiterIconSpeed1.visible = true
			else this.rpmLimiterIconSpeed1.visible = false end;	
			if speedLevel == 2 then this.rpmLimiterIconSpeed2.visible = true
			else this.rpmLimiterIconSpeed2.visible = false end;
			if speedLevel == 3 then this.rpmLimiterIconSpeed3.visible = true
			else this.rpmLimiterIconSpeed3.visible = false end;		
			if speedLevel == 4 then this.rpmLimiterIconSpeedS.visible = true
			else this.rpmLimiterIconSpeedS.visible = false end;				
		end;
	end;	
end;

function rpmLimiterSpec:delete()
end;

function rpmLimiterSpec:mouseEvent(posX, posY, isDown, isUp, button)
end;

function rpmLimiterSpec:keyEvent(unicode, sym, modifier, isDown)
end;

function rpmLimiterSpec:update(dt)	
    local this = rpmLimiterSpecHelper:getInstance(self.rootNode);
	
	if self.isMotorStarted and self.isEntered then	
		this.rpmLimiterCaptionLimit.text = tostring(math.ceil(self.motor.lastMotorRpm));
	
        if self.motor.speedLevel ~= 0 then
			this.rpmEditRpmInput.value		 	= tostring(self.motor.maxRpm[self.motor.speedLevel]);	
	    else
			this.rpmEditRpmInput.value		 	= tostring(self.motor.maxRpm[3]);	
	    end;
	
		if this.input:getAction('input.changeRpm') then
			Mods:setRegistry(this.modName, 'editMenuEnable', true, Registry.attr.write);
		end;		
		
		this.rpmEditUpButton.onClick 	= this.rpmIncrease;
		this.rpmEditDownButton.onClick	= this.rpmDecrease;
		this.changeSpeedIcon(self.motor.speedLevel);
	end;
end;	

function rpmLimiterSpec:draw()
	local this = rpmLimiterSpecHelper:getInstance(self.rootNode);

	this.rpmLimiterWindow:show();
	if Mods:getRegistry(this.modName, 'editMenuEnable') then this.rpmEditWindow:show() end;
end;