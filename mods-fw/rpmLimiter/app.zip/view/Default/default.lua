-------------------------------------------------------------+
-- Copyright � 2012 Rafa� Miko�ajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- rpmLimiter Mod
-- Default View
------------------------------------------------------------*/

local name = 'rpmLimiter_View_Default';
local _ = newclass(name, View);
_G[name] = _;

function _:init()
end;

function _:load()	
	self.controller = self:getController();

	--[[ UNDER CONSTRUCTION
	self.template = Template(self.ViewPrefix..'/templates/default');
	self.template:load();--]]
	
	-- rpmLimiter Widnow
	local window = {
		imagePath 		= self.ViewPrefix..'/images/gauge.png',
		width			= 0.235,
		height			= 0.040,	
		x_pos 			= 0.755,
		y_pos 			= 0.172,		
		disableCursor	= true,
	}
	-- Create Window
	self.rpmLimiterWindow = GraphicLayout(window);
	-- Add captions
	self.rpmLimiterCaptionLimit = self.rpmLimiterWindow:addCaption('0', 0.0, 0.005, 0.025, nil, true, nil, 'center', true);	
	-- Add Images
	self.rpmLimiterWindow:addImage(self.ViewPrefix..'/images/icon-rpm.dds', 0.0025, 0.008, 0.023, 0.026);
	self.rpmLimiterIconSpeed0 = self.rpmLimiterWindow:addImage(self.ViewPrefix..'/images/icon-speed0.dds', window.width-0.029, 0.0, 0.029, 0.040);
	self.rpmLimiterIconSpeed1 = self.rpmLimiterWindow:addImage(self.ViewPrefix..'/images/icon-speed1.dds', window.width-0.029, 0.0, 0.029, 0.040);
	self.rpmLimiterIconSpeed2 = self.rpmLimiterWindow:addImage(self.ViewPrefix..'/images/icon-speed2.dds', window.width-0.029, 0.0, 0.029, 0.040);
	self.rpmLimiterIconSpeed3 = self.rpmLimiterWindow:addImage(self.ViewPrefix..'/images/icon-speed3.dds', window.width-0.029, 0.0, 0.029, 0.040);
	self.rpmLimiterIconSpeedS = self.rpmLimiterWindow:addImage(self.ViewPrefix..'/images/icon-speedS.dds', window.width-0.029, 0.0, 0.029, 0.040);
	self.rpmLimiterIconSpeed1.visible = false;
	self.rpmLimiterIconSpeed2.visible = false;
	self.rpmLimiterIconSpeed3.visible = false;
	self.rpmLimiterIconSpeedS.visible = false;
	-- Init window
	addModEventListener(self.rpmLimiterWindow);	
	Mods:setRegistry(self.ViewPrefix, 'rpmLimiterWindow', self.rpmLimiterWindow);
	Mods:setRegistry(self.ViewPrefix, 'rpmLimiterCaptionLimit', self.rpmLimiterCaptionLimit);
	Mods:setRegistry(self.ViewPrefix, 'rpmLimiterIconSpeed0', self.rpmLimiterIconSpeed0);
	Mods:setRegistry(self.ViewPrefix, 'rpmLimiterIconSpeed1', self.rpmLimiterIconSpeed1);
	Mods:setRegistry(self.ViewPrefix, 'rpmLimiterIconSpeed2', self.rpmLimiterIconSpeed2);
	Mods:setRegistry(self.ViewPrefix, 'rpmLimiterIconSpeed3', self.rpmLimiterIconSpeed3);
	Mods:setRegistry(self.ViewPrefix, 'rpmLimiterIconSpeedS', self.rpmLimiterIconSpeedS);
	
	-- Add to LS 2011 mod list
	addModEventListener(self);
end;

function _:loadMap(name)
end;

function _:deleteMap()	
end;

function _:mouseEvent(posX, posY, isDown, isUp, button)
end;

function _:keyEvent(unicode, sym, modifier, isDown)
end;

function _:update(dt)
	self.controller:loadSpecialization();
end;

function _:draw()
	if g_currentMission.controlledVehicle == nil then self.rpmLimiterWindow:hide() end;
end;