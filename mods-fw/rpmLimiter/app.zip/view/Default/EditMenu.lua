-------------------------------------------------------------+
-- Copyright � 2012 Rafa� Miko�ajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- rpmLimiter Mod
-- Edit Menu View
------------------------------------------------------------*/

local name = 'rpmLimiter_View_Default_EditMenu';
local _ = newclass(name, View);
_G[name] = _;

function _:init()
end;

function _:load()	
	self.configFile = Mods:getRegistry(self.ViewPrefix, 'config');
	self.input = Mods:getRegistry(self.ViewPrefix, 'input');

	-- Edit Menu Widnow functions
	local function buttonClose(object, button, callbackData)
		Mods:setRegistry(self.ViewPrefix, 'editMenuEnable', false, Registry.attr.write);
		self.rpmEditWindow:hide();
	end;	
	
	-- Edit Menu Widnow
	local window = {
		imagePath 		= 'classic',
		width			= 0.56,
		height			= 0.25,		
		center			= true,
	}
	local margin = 0.02;
	-- Create Window
	self.rpmEditWindow = GraphicLayout(window);
	-- Add buttons
	self.rpmEditWindow:addButton(self.i18n:get('editWindow.closeButton'), btn.default.normal, btn.default.focused, btn.default.pressed, buttonClose, nil, margin, window.height-btn.default.height-margin, btn.default.width, btn.default.height, nil, btn.default.text);	
	self.rpmEditUpButton = self.rpmEditWindow:addButton('', btn.up.normal, btn.up.focused, btn.up.pressed, nil, nil, txtInput.default.width+0.03, 0.1, btn.up.width, btn.up.height);	
	self.rpmEditDownButton = self.rpmEditWindow:addButton('', btn.down.normal, btn.down.focused, btn.down.pressed, nil, nil, txtInput.default.width+0.03, 0.17, btn.down.width, btn.down.height);	
	-- Add text inputs
	self.rpmEditRpmInput = self.rpmEditWindow:addTextInput("rpm", '0', 1000, margin, 0.1);
	-- Add captions
	self.rpmEditWindow:addCaption(self.i18n:get('editWindow.title'), 0.0, margin, 0.04, nil, true, nil, 'center', true);
	-- Init window
	addModEventListener(self.rpmEditWindow);	
	Mods:setRegistry(self.ViewPrefix, 'editMenuEnable', false, Registry.attr.write);
	Mods:setRegistry(self.ViewPrefix, 'rpmEditWindow', self.rpmEditWindow);
	Mods:setRegistry(self.ViewPrefix, 'rpmEditRpmInput', self.rpmEditRpmInput);
	Mods:setRegistry(self.ViewPrefix, 'rpmEditUpButton', self.rpmEditUpButton);
	Mods:setRegistry(self.ViewPrefix, 'rpmEditDownButton', self.rpmEditDownButton);
	
	-- Add to LS 2011 mod list
	addModEventListener(self);	
end;

function _:loadMap(name)
end;

function _:deleteMap()	
end;

function _:mouseEvent(posX, posY, isDown, isUp, button)
end;

function _:keyEvent(unicode, sym, modifier, isDown)
end;

function _:update(dt)
	if g_currentMission.controlledVehicle ~= nil then 
		if g_currentMission.controlledVehicle.isMotorStarted and g_currentMission.controlledVehicle.isEntered then
			g_currentMission:addExtraPrintText(self.i18n:get('input.changeRpm')..': '..self.input:getActionKeyName('input.changeRpm'));
		end;
	end;
end;

function _:draw()
	if g_currentMission.controlledVehicle == nil then self.rpmEditWindow:hide() end;
end;