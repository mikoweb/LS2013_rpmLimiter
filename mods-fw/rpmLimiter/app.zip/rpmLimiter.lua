-------------------------------------------------------------+
-- Copyright © 2012 Rafał Mikołajun (MIKO) | rafal@mikoweb.pl
-- license: GNU General Public License version 3 or later; see LICENSE.txt
--
-- www.mikoweb.pl
-- www.swiat-ls.pl
--
-- rpmLimiter Mod
-- Initialization
------------------------------------------------------------*/

rpmLimiter_Mod = newclass("rpmLimiter_Mod");

function rpmLimiter_Mod:init(modName)
end;

function rpmLimiter_Mod:load()
	self.defaultController 	 = MVC_:getInstance(self.modName, 'Default');
end;